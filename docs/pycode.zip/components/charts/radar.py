"""
Model comparison radar chart.
Normalizes quality, speed, affordability, and context window
to 0–1 scale and overlays up to 5 selected models.
"""
import numpy as np
import pandas as pd
import plotly.graph_objects as go

from components.charts.constants import (
    PROVIDER_COLORS, DEFAULT_COLOR,
    BG as _BG, FONT as _FONT, empty_figure, QUALITY_INDEX_MAX, legend_below,
    plot_text, context_k,
    RADAR_SPEED_MAX, RADAR_PRICE_MAX, RADAR_LATENCY_MAX, RADAR_CONTEXT_K_MAX,
)

_PALETTE = [
    "#00d4ff", "#c084fc", "#34d399", "#fb923c", "#f472b6",
]

DIMS = ["Intelligence", "Speed", "Affordability", "Context", "Latency"]


def _context_k(ctx_str) -> float:
    """Delegates to the shared parser — see constants.context_k."""
    value = context_k(ctx_str)
    return 0.0 if value != value else value      # NaN -> 0 for the radius


def _log_norm(value: float, lo: float, hi: float, invert: bool = False) -> float:
    """Position a value on a log scale between lo and hi, clamped to [0, 1].

    Speed, price, context and latency are all heavy-tailed — speed runs
    24-2277 tok/s with most of the mass under 200, latency 0.2-102s with most
    under 5. On a linear scale the tail owns the axis and everything else piles
    at the origin: 139 of 156 models drew a Speed spoke under 10% of the radius,
    so a 298 tok/s model and a 52 tok/s model both read as "no speed".

    A log scale makes a *decade* the unit, which is how these quantities are
    actually reasoned about: 10x the speed is one step, whatever the base.
    """
    if not np.isfinite(value) or value <= 0 or hi <= lo:
        return 0.0
    lo = max(lo, 1e-9)
    frac = (np.log10(max(value, lo)) - np.log10(lo)) / (np.log10(hi) - np.log10(lo))
    frac = float(min(1.0, max(0.0, frac)))
    return 1.0 - frac if invert else frac


def _measured(value) -> float | None:
    """The value as a float, or None when the catalogue has no measurement.

    AA publishes 0 (or nothing) for a speed, latency or price it has not
    measured. _log_norm maps that to 0.0 before its invert branch, so an
    unmeasured latency drew as the SLOWEST possible spoke and an unmeasured
    speed as the slowest throughput — 21 of 195 hosted rows, including the top
    model, read as the worst in the catalogue on exactly the axes where the
    raw-values table beneath printed "—".
    """
    try:
        v = float(value)
    except (TypeError, ValueError):
        return None
    return v if np.isfinite(v) and v > 0 else None


def radar_reference(full_df: pd.DataFrame) -> dict:
    """The five axis endpoints, derived from the population rather than guessed.

    The old ceilings were hand-picked round numbers that had never been checked
    against the data, and every one of them was wrong in a way a visitor could
    see:

        axis          ceiling   pop max   consequence
        Intelligence     70.0     63.05   the best model could never reach 100%
        Speed          2500.0   1559.90   132/148 rendered inside the inner 10%
        Context (k)    2000.0   1000.00   every 1M model pinned at exactly 50.0%
        Price            50.0     40.00   —
        Latency          30.0    101.87   10 models clamped to a flat 0%, so a
                                          32s TTFT and a 102s TTFT drew the
                                          identical zero-length spoke

    Derived from the FULL catalogue and passed in, never from the frame being
    drawn: the subtitle promises a fixed reference, and a ceiling taken from a
    filtered frame would change a model's shape as the user filters.
    """
    q = pd.to_numeric(full_df.get("quality"), errors="coerce")
    s = pd.to_numeric(full_df.get("speed"), errors="coerce")
    p = pd.to_numeric(full_df.get("price"), errors="coerce")
    lat = pd.to_numeric(full_df.get("latency"), errors="coerce")
    ctx = full_df["context"].apply(_context_k) if "context" in full_df else pd.Series(dtype=float)

    def _lo(series, fallback):
        vals = series[series.notna() & (series > 0)] if series is not None and len(series) else None
        return float(vals.min()) if vals is not None and len(vals) else fallback

    def _hi(series, fallback):
        vals = series[series.notna() & (series > 0)] if series is not None and len(series) else None
        return float(vals.max()) if vals is not None and len(vals) else fallback

    return {
        "quality_max": _hi(q, QUALITY_INDEX_MAX),
        "speed_lo":    _lo(s, 1.0),      "speed_hi":   _hi(s, RADAR_SPEED_MAX),
        "price_lo":    _lo(p, 0.01),     "price_hi":   _hi(p, RADAR_PRICE_MAX),
        "ctx_lo":      _lo(ctx, 1.0),    "ctx_hi":     _hi(ctx, RADAR_CONTEXT_K_MAX),
        "lat_lo":      _lo(lat, 0.1),    "lat_hi":     _hi(lat, RADAR_LATENCY_MAX),
    }


def build_radar(df: pd.DataFrame, selected_models: list[str] | None = None,
                full_df: pd.DataFrame | None = None) -> go.Figure:
    # `[]` is a deliberate clear and must show the empty state; `None` is "no
    # selection supplied", which is the genuine first render. Substituting the
    # top 5 for both meant clearing the control charted five models while the
    # raw-values table directly beneath went blank — the two disagreeing about
    # what was being compared, with the <select> visibly empty.
    if selected_models is not None and len(selected_models) == 0:
        return empty_figure("Select up to 5 models to compare")
    if not selected_models:
        # Default: top-5 by quality
        selected_models = (
            df[df["quality"] > 0]
            .sort_values(["quality", "model"], ascending=[False, True], kind="mergesort")
            .head(5)["model"]
            .tolist()
        )

    plot_df = df[df["model"].isin(selected_models)].copy()
    if plot_df.empty:
        # A bare go.Figure() renders with Plotly's default WHITE canvas, which
        # flashed a blank white card inside the dark dashboard whenever the
        # selection was cleared.
        return empty_figure("Select up to 5 models to compare")

    # Fixed reference per axis, derived from the FULL catalogue. Both render
    # paths hand this function an already-filtered frame, so taking endpoints
    # from `df` would rescale the axes with the provider/search filters — the
    # same model's profile would change shape, and the subtitle's "normalized
    # across all models" would be untrue. `full_df` is the whole catalogue;
    # falling back to `df` keeps a bare two-argument call working.
    ref = radar_reference(full_df if full_df is not None and not full_df.empty else df)

    fig = go.Figure()
    any_missing = False

    for idx, model_name in enumerate(selected_models):
        rows = plot_df[plot_df["model"] == model_name]
        if rows.empty:
            continue
        row = rows.iloc[0]

        # A metric the catalogue does not have is MISSING, not a score: its
        # vertex is None, which Plotly draws as a gap in the outline, and the
        # hover says "not measured" instead of printing 0%.
        quality = _measured(row["quality"])
        speed   = _measured(row["speed"])
        price   = _measured(row["price"])
        ctx_k   = _measured(_context_k(row.get("context", "")))
        latency = _measured(row.get("latency"))

        # Intelligence is the one axis that is already roughly uniform, so it
        # stays linear against the population max — the best model reads 100%.
        # Clamped to [0, 1]: a model above the reference max would otherwise
        # exceed the ring, and a negative radius is drawn straight through the
        # centre of the polar plot.
        values = [
            (min(1.0, max(0.0, quality / ref["quality_max"]))
             if quality is not None and ref["quality_max"] else None),
            (_log_norm(speed, ref["speed_lo"], ref["speed_hi"])
             if speed is not None else None),
            # Affordability: cheap is good, so the price axis is inverted.
            (_log_norm(price, ref["price_lo"], ref["price_hi"], invert=True)
             if price is not None else None),
            (_log_norm(ctx_k, ref["ctx_lo"], ref["ctx_hi"])
             if ctx_k is not None else None),
            # Latency: lower is better — inverted.
            (_log_norm(latency, ref["lat_lo"], ref["lat_hi"], invert=True)
             if latency is not None else None),
        ]
        values_txt = ["not measured" if v is None else f"{round(v * 100)}%"
                      for v in values]
        any_missing = any_missing or any(v is None for v in values)

        # One trace per MODEL, so colour must vary per model. Keying it on the
        # provider drew two Anthropic models in the identical hue and fill,
        # making the one chart whose whole job is comparison unable to tell
        # them apart. _PALETTE is indexed by trace instead, which is also what
        # its per-index design was always for.
        color = _PALETTE[idx % len(_PALETTE)]
        fillcolor = f"rgba({int(color[1:3],16)},{int(color[3:5],16)},{int(color[5:7],16)},0.18)"
        gapped = any(v is None for v in values)

        # fill="toself" closes EACH gap-separated segment into its own shape,
        # so on a gapped outline it drew a chord across the missing spoke
        # (implying ~31% where nothing was measured) and, with two gaps, left
        # nothing but zero-area slivers. A gapped model therefore gets an
        # unfilled outline with markers — so a lone measured vertex between
        # two gaps is still visible — and its area comes from the separate
        # fill trace below, which pins each missing vertex to the centre.
        fig.add_trace(go.Scatterpolar(
            r=values + [values[0]],
            theta=DIMS + [DIMS[0]],
            connectgaps=False,
            mode="lines+markers" if gapped else "lines",
            marker=dict(color=color, size=5),
            fill="none" if gapped else "toself",
            fillcolor=fillcolor,
            line=dict(color=color, width=1.5),
            legendgroup=f"radar-{idx}",
            # Escaped: Plotly renders legend text as markup, and a poisoned
            # model name produced a live <a> styled as a legend entry.
            name=plot_text(model_name[:28] + ("…" if len(model_name) > 28 else "")),
            hovertemplate=(
                f"<b>{plot_text(model_name)}</b><br>"
                f"Intelligence: {values_txt[0]}<br>"
                f"Speed: {values_txt[1]}<br>"
                f"Affordability: {values_txt[2]}<br>"
                f"Context: {values_txt[3]}<br>"
                f"Latency: {values_txt[4]}<br>"
                "<extra></extra>"
            ),
        ))
        if gapped:
            # Area only: unnamed, out of the legend and the hover, and grouped
            # with its outline so a legend click hides both.
            filled = [0.0 if v is None else v for v in values]
            fig.add_trace(go.Scatterpolar(
                r=filled + [filled[0]],
                theta=DIMS + [DIMS[0]],
                mode="lines",
                fill="toself",
                fillcolor=fillcolor,
                line=dict(width=0, color=color),
                hoverinfo="skip",
                showlegend=False,
                legendgroup=f"radar-{idx}",
            ))

    fig.update_layout(
        paper_bgcolor=_BG,
        plot_bgcolor=_BG,
        font=dict(family=_FONT, color="#999999", size=12),
        title=dict(
            text=(
                "Model Comparison"
                "  <span style='font-size:12px;color:#777777;font-weight:400'>"
                "  ·  0–100% against the full catalogue; speed, price, context "
                "and latency on a log scale"
                f"{'  ·  a gap in an outline = not measured' if any_missing else ''}"
                "</span>"
            ),
            font=dict(size=15, color="#f2f2f2", family=_FONT, weight=600),
            x=0.0, xanchor="left",
            pad=dict(l=20, t=16),
        ),
        polar=dict(
            bgcolor=_BG,
            radialaxis=dict(
                visible=True,
                range=[0, 1],
                tickformat=".0%",
                tickfont=dict(color="#777777", size=9, family=_FONT),
                gridcolor="rgba(255,255,255,0.05)",
                linecolor="rgba(255,255,255,0.05)",
                showline=True,
            ),
            angularaxis=dict(
                tickfont=dict(color="#999999", size=12, family=_FONT),
                gridcolor="rgba(255,255,255,0.06)",
                linecolor="rgba(255,255,255,0.06)",
            ),
        ),
        # Model names are long, so the vertical legend was wider than its own
        # 160px gutter and overlapped the polar plot on narrow viewports.
        legend=legend_below(y=-0.08),
        margin=dict(l=60, r=40, t=52, b=110),
        hovermode="closest",
        hoverlabel=dict(
            bgcolor="#161616", bordercolor="rgba(255,255,255,0.1)",
            font=dict(color="#f2f2f2", size=12, family=_FONT), namelength=-1,
        ),
    )

    return fig
