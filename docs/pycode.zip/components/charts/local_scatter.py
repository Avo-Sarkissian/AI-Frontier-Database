"""
Local models — VRAM vs Quality scatter chart.

X-axis : VRAM required (GiB) at the selected quantization AND context —
         weights + KV cache + runtime overhead — log scale
Y-axis : AA Intelligence Index (raw, calibrated to AA scale)
Size   : tokens/second — single-stream or aggregate at optimal concurrency,
         whichever the SPEED control selects
Color  : Model family (the legend encodes colour ONLY)
Shape  : ● dense  ◆ MoE (mixture-of-experts) — never the lab

A vertical dashed line marks the user's available VRAM.
Models to the left of the line are runnable; those to the right are not.
"""
import pandas as pd
import plotly.graph_objects as go

from components.charts.constants import (
    plot_text,
    BG as _BG, GRID as _GRID, TICK as _TICK, AXIS as _AXIS, FONT as _FONT,
    bubble_size, legend_below, QUALITY_INDEX_MAX, LOCAL_SPEED_REF,
    LOCAL_THROUGHPUT_REF,
)
from components.charts.local_compat import (
    KV_NOTE, ESTIMATED_KV_NOTE, ctx_labels, speed_notes,
)
from data.local_models import (
    FAMILY_COLORS, DEFAULT_FAMILY_COLOR, DEFAULT_SPEED_MODE, speed_columns,
)

_FIT_ALPHA  = 1.00   # fully runnable
_TIGHT_ALPHA = 0.75  # fits but < 1 GB headroom
_NO_ALPHA   = 0.25   # won't fit — greyed out


def _ctx_label(ctx_tokens) -> str:
    """"32k", not "32768"."""
    try:
        n = int(ctx_tokens or 0)
    except (TypeError, ValueError):
        return "?"
    if n <= 0:
        return "0"
    return f"{n // 1024}k" if n >= 1024 else str(n)


def build_local_scatter(
    df: pd.DataFrame,
    vram_gb: float,
    quant: str,
    ctx_tokens=None,
    speed_mode: str = DEFAULT_SPEED_MODE,
) -> go.Figure:
    """
    Scatter: VRAM required vs quality score.
    df is the output of data.local_models.get_local_df().
    """
    if df.empty:
        return _empty("No models found.")

    # This chart's Y axis IS the quality score, so a model nobody has scored
    # cannot be placed on it. Dropping it silently would be the same lie in the
    # other direction, so the count is surfaced in the subtitle and the model is
    # still listed — with an outlined bar — in the compatibility chart below.
    _pending_n = 0
    if "pending" in df.columns:
        _mask = df["pending"].fillna(False) & df["quality"].isna()
        _pending_n = int(_mask.sum())
        df = df[~_mask]
    if df.empty:
        return _empty("No scored models found.")

    _speed_col, _speed_label = speed_columns(speed_mode)
    _speed_ref = (LOCAL_THROUGHPUT_REF if speed_mode == "throughput"
                  else LOCAL_SPEED_REF)

    # Whether the KV figure in the hover came from a published config or the
    # fitted estimator, the per-row context actually priced, and the speed
    # line. All three are shared with local_compat.py so the two hovers say the
    # same thing about the same row — see the notes there.
    df = df.copy()
    df["kv_note"] = (df["kv_source"] if "kv_source" in df else "none") \
        .map(KV_NOTE).fillna(ESTIMATED_KV_NOTE)
    df["ctx_label"], _n_capped = ctx_labels(df, ctx_tokens)
    df["speed_note"] = speed_notes(df, speed_mode)
    for _c in ("weights_gb", "kv_gb", "sessions", "total_tps"):
        if _c not in df:
            df[_c] = 0

    fig = go.Figure()

    # Draw each family as its own trace so the legend is grouped by family
    # Families that actually got a runnable mark. The old rule was
    # showlegend=(fits_val == "yes"), so a family with nothing that fits never
    # appeared; the proxies have to reproduce that or the legend grows by the
    # 18 families whose models are all too big for the selected hardware.
    _legend_families: list = []
    for family, fdf in df.groupby("family", sort=False):
        color = FAMILY_COLORS.get(family, DEFAULT_FAMILY_COLOR)
        if not fdf[fdf["fits"] == "yes"].empty:
            _legend_families.append(family)

        for fits_val, opacity in [("yes", _FIT_ALPHA), ("tight", _TIGHT_ALPHA), ("no", _NO_ALPHA)]:
            sub = fdf[fdf["fits"] == fits_val]
            if sub.empty:
                continue

            # Scale bubble size: sqrt of tok/s so fast models aren't enormous.
            # The reference is per-metric — aggregate throughput runs 2-4x
            # single-stream, so sharing one would clamp every bubble in
            # throughput mode and the size channel would stop encoding anything.
            sizes = bubble_size(sub[_speed_col], _speed_ref).values

            hover = (
                "<b>%{customdata[0]}</b><br>"
                f"Family: {plot_text(family)}<br>"
                "VRAM required: %{x:.1f} GB at %{customdata[8]} context<br>"
                "  ↳ weights %{customdata[5]:.1f} + KV cache %{customdata[6]:.1f}"
                " + runtime %{customdata[11]:.1f} GB  ·  %{customdata[7]}<br>"
                "Intelligence: %{y:.0f}<br>"
                "%{customdata[12]}<br>"
                "License: %{customdata[2]}<br>"
                "Max context: %{customdata[3]}k tokens<br>"
                "Tags: %{customdata[4]}<br>"
                "<extra></extra>"
            )

            fig.add_trace(go.Scatter(
                x=sub["vram_req_gb"],
                y=sub["quality"],
                mode="markers",
                name=plot_text(family),
                # NEVER the legend entry. The symbol is a per-point array, so
                # Plotly draws the swatch with whichever model happens to sort
                # first in the family — Alibaba came out a circle and NVIDIA a
                # diamond purely by accident of ordering, which reads as though
                # SHAPE encoded the lab. It encodes dense vs MoE. The legend is
                # drawn from fixed-symbol proxies below so it carries colour and
                # nothing else.
                showlegend=False,
                legendgroup=plot_text(family),
                marker=dict(
                    color=color,
                    opacity=opacity,
                    size=sizes,
                    sizemode="diameter",
                    # Per POINT, not per subgroup: `sub["moe"].any()` drew every
                    # dense model in a mixed family as a diamond, making the
                    # on-chart "◆ = MoE" key false for 24 of 38 dense models.
                    symbol=["diamond" if m else "circle" for m in sub["moe"]],
                    line=dict(width=0.5, color="rgba(255,255,255,0.15)"),
                ),
                # customdata is POSITIONAL — every %{customdata[N]} above indexes
                # into this list, so a column added here without updating the
                # template silently shifts every later field.
                customdata=sub.assign(
                    name=sub["name"].map(plot_text),
                    license=sub["license"].map(plot_text),
                    tags_str=sub["tags_str"].map(plot_text),
                )[["name", "speed_tps", "license", "context_k", "tags_str",
                   "weights_gb", "kv_gb", "kv_note", "ctx_label",
                   "sessions", "total_tps", "overhead_gb", "speed_note"]].values,
                hovertemplate=hover,
            ))

    # Legend proxies: one per family, fixed circle, no data. They exist so the
    # FAMILY legend encodes colour only. The dense/MoE key is the annotation in
    # the corner, which is the one place shape is explained.
    for family in _legend_families:
        fig.add_trace(go.Scatter(
            x=[None], y=[None], mode="markers",
            name=plot_text(family), legendgroup=plot_text(family),
            marker=dict(color=FAMILY_COLORS.get(family, DEFAULT_FAMILY_COLOR),
                        size=9, symbol="circle",
                        line=dict(width=0.5, color="rgba(255,255,255,0.15)")),
            hoverinfo="skip", showlegend=True,
        ))

    # Vertical threshold line at user's VRAM
    fig.add_vline(
        x=vram_gb,
        line=dict(color="rgba(0,212,255,0.55)", width=1.5, dash="dot"),
        annotation_text=f"  {vram_gb:.0f} GB",
        annotation_font=dict(color="#00d4ff", size=10, family=_FONT),
        annotation_position="top right",
    )

    # Shaded "runnable" region (left of threshold)
    fig.add_vrect(
        x0=0, x1=vram_gb,
        fillcolor="rgba(34,197,94,0.025)",
        line_width=0,
        layer="below",
    )

    import math

    # The axis is logarithmic, so including the 600B-class models costs a
    # little width rather than compressing the runnable region — and dropping
    # them silently removed a third of the catalogue from the chart.
    x_max = max(vram_gb * 2.5, float(df["vram_req_gb"].max()) * 1.15, 8)
    x_log_max = math.log10(x_max)
    x_log_min = math.log10(0.08)   # ~0.08 GB minimum so tiny models show

    # Build sensible tick positions within the visible range. The doubling
    # ladder runs as far as the axis does: it used to stop at a fixed 512, while
    # x_max reaches ~1.8 TB at the default and more on pooled GPUs, so the VRAM
    # line and the 600B-class models sat in an unlabelled last eighth of the
    # axis. Doubling until the axis end keeps the final gap no wider than the
    # others.
    all_tick_vals = [0.1, 0.25, 0.5]
    _v = 1
    while _v <= x_max * 1.05:
        all_tick_vals.append(_v)
        _v *= 2
    all_tick_texts = [f"{v:g}" for v in all_tick_vals]
    tick_pairs = [(v, t) for v, t in zip(all_tick_vals, all_tick_texts) if v <= x_max * 1.05]
    tick_vals  = [p[0] for p in tick_pairs]
    tick_texts = [p[1] for p in tick_pairs]

    fig.update_layout(
        paper_bgcolor=_BG,
        plot_bgcolor=_BG,
        font=dict(family=_FONT, color="#999999", size=12),
        title=dict(
            text=(
                "VRAM Requirement vs Intelligence"
                "  <span style='font-size:12px;color:#777777;font-weight:400'>"
                f"  ·  {quant} at {_ctx_label(ctx_tokens)} context"
                + (f" ({_n_capped} priced at their own shorter max)" if _n_capped else "")
                + "  ·  left of line = runnable  ·  bubble = "
                f"{_speed_label} tok/s"
                + (f"  ·  {_pending_n} newer model{'s' if _pending_n != 1 else ''} "
                   f"not yet scored — see the ranking below" if _pending_n else "")
                + "</span>"
            ),
            font=dict(size=15, color="#f2f2f2", family=_FONT, weight=600),
            x=0.0, xanchor="left",
            pad=dict(l=20, t=16),
        ),
        xaxis=dict(
            title=dict(text="VRAM Required (GB)", font=dict(color=_AXIS, size=12), standoff=12),
            type="log",
            range=[x_log_min, x_log_max],
            gridcolor=_GRID, zerolinecolor="rgba(255,255,255,0.06)",
            tickfont=dict(color=_TICK, size=11, family=_FONT),
            showgrid=True, showline=False, ticks="",
            tickvals=tick_vals,
            ticktext=tick_texts,
        ),
        yaxis=dict(
            title=dict(text="AA Intelligence Index", font=dict(color=_AXIS, size=12), standoff=12),
            range=[0, QUALITY_INDEX_MAX],
            gridcolor=_GRID, zerolinecolor="rgba(255,255,255,0.06)",
            tickfont=dict(color=_TICK, size=11, family=_FONT),
            showgrid=True, showline=False, ticks="",
        ),
        # Up to 26 family entries in a vertical side legend meant ~10 were
        # hidden behind a Plotly scrollbar, while its fixed 160px gutter left
        # the plot 35% of the card on a phone.
        legend={**legend_below(y=-0.14),
                "font": dict(color="#999999", size=10, family=_FONT),
                "title": dict(text="FAMILY", font=dict(color="#777", size=10))},
        margin=dict(l=56, r=28, t=52, b=132),
        hovermode="closest",
        hoverlabel=dict(
            bgcolor="#161616", bordercolor="rgba(255,255,255,0.1)",
            font=dict(color="#f2f2f2", size=12, family=_FONT), namelength=-1,
        ),
    )
    # Legend annotation for size = speed. ADDED, not passed to update_layout:
    # update_layout(annotations=[...]) replaces the tuple, which silently wiped
    # the "N GB" label add_vline had attached to the VRAM line above, so the
    # runnable boundary was drawn with no value on it.
    # yanchor="top" is explicit because the old replace merged it in from the
    # VRAM label it overwrote; the key has always rendered top-anchored.
    fig.add_annotation(
        x=1.0, y=1.04, xref="paper", yref="paper",
        xanchor="right", yanchor="top",
        text=(f"● dense   ◆ mixture-of-experts"
              f"<br>bubble size = {_speed_label} tok/s"
              f"<br>colour = lab"),
        showarrow=False,
        font=dict(color="#666666", size=10, family=_FONT),
        align="left",
    )

    return fig


def _empty(msg: str) -> go.Figure:
    fig = go.Figure()
    fig.update_layout(
        paper_bgcolor=_BG, plot_bgcolor=_BG,
        font=dict(family=_FONT, color="#888888", size=12),
        annotations=[dict(
            x=0.5, y=0.5, xref="paper", yref="paper",
            text=msg, showarrow=False,
            font=dict(color="#777777", size=13, family=_FONT),
        )],
        margin=dict(l=40, r=40, t=60, b=40), height=500,
    )
    return fig
