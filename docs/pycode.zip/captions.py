"""Chart captions — ONE source for both renderings.

app.py rendered 14 of these; docs/app.js rendered exactly one, so the public
site — the one that actually deploys — shipped nine tabs with no explanation of
what the reader was looking at. Two copies of the same prose would have drifted
the way the palettes and the price semantics did, so the text lives here, app.py
reads it directly, and build_static.py ships it in the manifest for the browser.
"""

CAPTIONS: dict[str, str] = {
    'overview_price': (
"Each bubble is one model FAMILY — the best-scoring variant, so five Claude Opus 5 effort tiers "
        "collapse to one point rather than five near-duplicates at the same price. X = price "
        "per 1M tokens at the MIX setting (log scale; default = our 1:3 in:out blend, not AA's), "
        "Y = AA Intelligence Index. Bubble size = throughput (tok/s). "
        "Hollow = open weights, filled = closed (Artificial Analysis's flag; WEIGHTS filters "
        "them). Dotted line = Pareto frontier, recomputed for the mix. Click any bubble for full details."
    ),
    'recommend': (
        "Build your Claude Code model stack. API Only = all cloud. Hybrid — Fast "
        "local = free local for sub-tasks, API for Balanced + Reasoning. Hybrid — "
        "Fast + Balanced local = local for both workhorse tiers, API only for the "
        "top orchestrator. Local Only = fully offline. Fast = high-volume "
        "sub-tasks. Balanced = coding and writing. Reasoning = planning and "
        "delegation."
    ),
    'landscape_treemap': (
        "AI ecosystem by provider. Tile area = number of models in the dataset. "
        "Color intensity = average intelligence score."
    ),
    'landscape_leaderboard': (
        "Provider leaderboard: bar length = best model's intelligence. Tick mark = "
        "provider average. Right labels show model count and top model."
    ),
    'rankings_intelligence': (
        "Intelligence = AA Intelligence Index (composite benchmark). Value = "
        "Intelligence ÷ Price (higher = more score per dollar). Speed = throughput "
        "in tokens/second. Models within ±2 points of each other are effectively "
        "tied — small deltas are within measurement variance. About half these "
        "scores are estimated by Artificial Analysis rather than measured: since "
        "its 2026-09 rebuild it extrapolates the index for models it has not yet "
        "run the full evaluation suite on. Click any model for which it is. "
        "Outlined bars = open weights (Artificial Analysis's flag, or a name match "
        "to its open-weights list where a row has no flag; the hover says which), "
        "solid = closed."
    ),
    'rankings_value': (
        "Top 15 models ranked by intelligence per dollar (quality score ÷ price per "
        "1M tokens at the MIX setting, so an input-heavy or cached workload can "
        "re-rank the list). Quality floor of 20 so ultra-cheap but weak models don't "
        "pollute the list. Bar length = value score. Labels show raw quality and "
        "price."
    ),
    'compare': (
        "Radar comparing up to 5 models across 5 dimensions, each scaled 0–100% "
        "between the weakest and strongest model in the full catalogue — so a shape "
        "means the same thing whatever the filter. Speed, price, context and "
        "latency are heavy-tailed, so those four use a log scale: one step is a 10× "
        "change, not a fixed amount. Affordability = inverted price (100% = "
        "cheapest). Latency = inverted TTFT (100% = fastest). Raw values for each "
        "model are shown in the table below the chart."
    ),
    'budget': (
        "Estimate monthly API cost. Price is the effective $/1M tokens for the "
        "workload MIX in the filter bar: input:output ratio and cache-hit rate "
        "applied to Artificial Analysis's per-token rates. The default is our own "
        "blend, 1 part input to 3 parts output with no cache — not AA's, whose "
        "published blend weights it the other way. Presets: chat 1:1, AA's 3:1, "
        "15:1 observed (late-2025 averages in the a16z × OpenRouter State of AI "
        "study, quoted; a lower bound), and agentic 300:1 with 90% cached (a "
        "SemiAnalysis estimate), or type your own. Cache-hit prices are "
        "Artificial Analysis's; where it publishes none, cache hits are billed at "
        "the full input price (no discount assumed), marked * and counted on the "
        "chart. "
        "Cache-write premiums are not modelled. Enter volume in millions of total "
        "tokens — 1M tokens ≈ 750,000 words or ~1,500 pages. Chart sorts "
        "cheapest-first."
    ),
    'table': (
        "Full sortable model table. Score = AA Intelligence Index (composite "
        "benchmark, higher = better) — about half are estimated by Artificial "
        "Analysis rather than measured, which the ↓CSV export marks per row. "
        "Value = Score ÷ Price (quality per dollar). Price = effective $/M tokens "
        "at the MIX setting; the column header names it (default: our 1:3 "
        "in:out blend, not AA's). Latency = time-to-first-token (TTFT) in seconds."
    ),
    'local': (
        "Model specs come from Artificial Analysis, plus a short curated list of "
        "notable open-weight releases AA has not benchmarked yet — those are drawn "
        "with an outlined bar and no score, never a guessed one, and are excluded "
        "from the Agent Stack recommendations. "
        "VRAM covers model WEIGHTS, the KV cache at the context you select, and "
        "about 1.5 GB of runtime overhead. The KV cache is the term that used to "
        "be missing and it is not small: Llama 3.1 8B at Q4 needs about 7 GB at 8k "
        "and about 22 GB at its advertised 128k — the KV cache alone goes from "
        "1 GB to 16 GB. Attention geometry comes from "
        "each model's published config where this dashboard carries it and is "
        "estimated from parameter count otherwise — the hover says which. About "
        "four in five models now carry a published figure; the rest are estimates, and an estimate here can be badly wrong for a "
        "model with sliding-window or latent attention, which the estimator cannot see. "
        "Scores are benchmarked at the model's native precision and do NOT move "
        "with the quantization control: lowering it here shrinks VRAM and raises "
        "speed at no visible cost, but real quality does fall, steeply at the "
        "levels marked lossy. Artificial Analysis does not publish quantized "
        "scores and this dashboard will not guess one. "
        "Speed is a roofline estimate (±30%) for token generation, not prompt "
        "processing: the slower of the memory stream (weights + KV cache) and the "
        "compute ceiling, and on every GPU here it is the memory stream, by 13x to "
        "198x. Quantizing does not buy its full byte ratio — FP16 to Q2 is about "
        "3.6x here and 1.9x–4.0x in published measurements, not the 8x a linear "
        "model implies — and the gain shrinks further at long context, because the "
        "KV cache stays FP16 whatever the weights are. It remains an upper bound "
        "for MoE models. The SPEED control picks which tok/s figure the chart shows: "
        "single stream is one conversation at a time; max throughput is the total "
        "across as many concurrent sessions as the KV cache fits in VRAM while each "
        "one still decodes at 10 tok/s or better (MLPerf's Llama-3.1-8B Server "
        "floor, ~480 words/minute). The two are 2-4x apart, so only one is on "
        "screen at a time and the hover carries the other. Both are decode-only "
        "and say nothing about queueing or time-to-first-token. "
        "Find open-weight models you can run on your own hardware. Select your GPU "
        "(or enter VRAM manually), choose a quantization level and a context "
        "length, and see which models fit — with estimated throughput."
    ),
    'image': (
        "Compare image generation models by quality and style. ELO scores from "
        "the Artificial Analysis Image Arena — blind pairwise human votes, so "
        "they rank models against each other and have no meaningful zero. "
        "Overall ELO and price refresh hourly. The per-style scores each column "
        "ranks on do not: Artificial Analysis retired its public per-category "
        "breakdown on 2026-09-07 and now publishes it only to API-key holders, "
        "so those are the last published figures and a model released since "
        "then carries none. Annotations show price per 1,000 images."
    ),
    'video': (
        "Compare video generation models on quality and cost, scraped hourly from the "
        "Artificial Analysis Video Arena. Elo comes from blind pairwise human votes, so "
        "it ranks models against each other and has no meaningful zero — read position, "
        "not distance from the axis. Text-to-video and image-to-video are separate "
        "arenas with separate prices, so MODE switches between them rather than blending "
        "them. Price is per minute of video at each provider's default settings; "
        "generation time is measured end-to-end and AA currently publishes it for only a "
        "handful of models. The ranked view shows current models; superseded preview "
        "builds stay in the ↓CSV export."
    ),
    'overview_speed': (
        "Speed (tok/s) vs. AA Intelligence Index. Top-right = fast and smart. "
        "Bubble size = affordability (larger = cheaper). Hollow = open weights. "
        "Click any bubble for full details."
    ),
    'overview_task': (
        "Each bubble is one model FAMILY — its best-scoring variant that Artificial "
        "Analysis has costed (with EFFORT set, the nearest tier AA has costed). X = "
        "AA's cost per Intelligence Index task (USD, log scale): the token counts the "
        "provider reported for the run (a canonical tokenizer where none were "
        "reported), reasoning included, with cache reads at AA's live measurement of "
        "the model's typical cache-hit rate rather than the hits seen in the run. MIX "
        "does not move it. "
        "Models AA has not costed are counted in the title, never estimated. Y = AA "
        "Intelligence Index. Bubble size = throughput (tok/s). Dotted line = Pareto "
        "frontier on cost per task. Token burn in the hover and detail panel = cost "
        "per task ÷ list price per token. Source: artificialanalysis.ai. Click any "
        "bubble for full details."
    ),
    'economics_open_gap': (
        "Open weights vs. closed, three ways, all from Artificial Analysis data "
        "this dashboard scrapes (artificialanalysis.ai). Open or closed is AA's "
        "isOpenWeights flag; a row without one (every daily snapshot before "
        "2026-10-27) is classified by an exact-name match to AA's open-weights "
        "list, kept from every revision since 2026-05-06, and otherwise counted "
        "as closed. SCORE GAP: in each daily snapshot, the best closed model's AA "
        "Intelligence Index minus the best open model's. AA has rescaled the "
        "index — found in the snapshots on 2026-06-16, 2026-09-05 and 2026-09-08 "
        "(nearly every model moved by one factor) — so the line breaks there and a "
        "gap is comparable only within one segment; the 2026-03-07 snapshot, when "
        "AA briefly published the index renormalised to 0–100, is left out. Early "
        "snapshots can still overstate the gap where an open model left every "
        "list this dashboard kept. RELEASE LAG: for each closed model that set a "
        "new closed high when released, the time until an open model scoring at "
        "least as much was released; one not matched yet is counted, not given a "
        "number. Only models AA still lists are seen (it drops superseded ones), "
        "so this is a survivor's view, not a measured history. PRICE: for each "
        "open family, the price of the cheapest closed family scoring at least "
        "as well, divided by the open model's price, both at our 1:3 in:out "
        "blend (the Economics tab does not follow MIX). AA lists one price per "
        "model, not the cheapest third-party host, and the spread runs both ways, "
        "so no single ratio is claimed. For comparison, quoted: Epoch AI finds "
        "open models trailing the closed frontier by about four months since "
        "January 2026 on its Capabilities Index (epoch.ai/data-insights/"
        "open-closed-eci-gap, 2026-05-29, CC BY 4.0); OpenRouter reports open "
        "models above 62% of its tokens while closed models took 73% of spend "
        "in September 2026 (openrouter.ai/data/newsletter/the-token-state-of-play, "
        "quoted, not scraped); Nous Research measured open reasoning models using "
        "about 1.5–4× the tokens of closed ones on the same tasks (nousresearch.com/"
        "measuring-thinking-efficiency-in-reasoning-models-the-missing-benchmark), "
        "which a per-token price ratio does not see — the hover adds AA's cost per "
        "task where AA publishes one for both models."
    ),
    'overview_price_dyn': (
"Each bubble is one model FAMILY — the best-scoring variant, so five Claude Opus 5 effort tiers "
        "collapse to one point rather than five near-duplicates at the same price. X = price "
        "per 1M tokens at the MIX setting (log scale; default = our 1:3 in:out blend, not AA's), "
        "Y = AA Intelligence Index. Bubble size = throughput (tok/s). "
        "Hollow = open weights, filled = closed (Artificial Analysis's flag; WEIGHTS filters "
        "them). Dotted line = Pareto frontier, recomputed for the mix. Click any bubble for full details."
    ),
}
